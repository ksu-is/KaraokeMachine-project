## KaraokeMachine (Winter 2016)
Karaoke Machine and Grader

My project is a voice-grading karaoke machine that plays music, records your voice, and prints lyrics on the screen simultaneously for the karaoke component. This program also grades the user's singing based on frequency matching of the real audio file and the user's recorded file for the voice-grading component. The score will lead after the song ends.

This program does not use any third party library, so simply download the program, run the main file, KaraokeMachine.py, and navigate through the Tkinter interface. While there are no third party libraries or required hardware, it is strongly recommended that headphones/earphones are used when using the karaoke machine in order to increase accuracy of the frequency matching algorithm. 

Sources:
play(outputFile) [KaraokeMachine.py] - outside source

record(inputFile) [KaraokeMachine.py] - outside source

getPitch(filename) [KaraokeMachine.py] - external github resource

run() [KaraokeMachine.py] - CMU 15-112 Notes
